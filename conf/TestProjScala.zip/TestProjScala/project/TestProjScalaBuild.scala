import sbt._
import sbt.Keys._

object TestProjScalaBuild extends Build {

  lazy val project = Project(
    id = "TestProjScala",
    base = file("."),
    settings = Project.defaultSettings ++ Seq(
      name := "TestProjScala",
      organization := "com.example",
      version := "0.1-SNAPSHOT",
      scalaVersion := "2.10"
    )
  )
}
